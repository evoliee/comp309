Hello,

so just making sure I got the setup right, because honestly, I am very confused and sleep-deprived but here's the basics.

folder
	- allCode.ipynb # I worked here.
	- report.pdf
	- train.py
	- model.pth
	- test.py
	- testdata
		- lots of images
	- traindata
		- also lots of images
		
I commented out the line that allows you to split images. Hope that's correct. Sorry if not.

Manuela Spies
300491313